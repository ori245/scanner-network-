import socket
import requests


def scanOnePort(host):
    port = int(input('Enter the port to scan: '))
    print('Scanning port %s...' % str(port))
    portScan(port)
    print('\n')

def scanAllPorts(host):
    for i in range(1, 49151):
        port = i
        print('Scanning port %s...' % str(port))
        portScan(port)

    print('\n')

def Checkingsite(host):
    print("Checking site status(Success=200) please enter domain ")
    x = requests.get(input(''))
    if x:
        print('Success!')
    else:
        print('error')



socketId = socket.socket(socket.AF_INET, socket.SOCK_STREAM)


def portScan(port):
    if socketId.connect_ex((host, port)):
        print('The port is closed!')
    else:
        print('The port is open')

host = input('If you want to see port information enter ip if not Enter: ')