from script import scanOnePort,scanAllPorts,host,portScan,Checkingsite

print("""
***************************
**********By-Ori***********
***************************
""")

class menu_info:
  def __init__(self, info):
    self.info = info
a = menu_info("What do you want to do? Here a list of options:")
print(a.info)

class menu_info1:
  def __init__(self, info1):
    self.info1 = info1
b = menu_info1("[1] Scan a single port")
print(b.info1)

class menu_info2:
  def __init__(self, info2):
    self.info2 = info2
c = menu_info2("[2] Scan all ports")
print(c.info2)

class menu_info3:
  def __init__(self, info3):
    self.info3 = info3
c = menu_info3("[3] Checking site status")
print(c.info3)



def menu():
    print('[0] close\n')
    action = int(input('Insert the number of the action: '))
    return action

while True:
    action = menu()

    if action == 0:
        break
    elif action == 1:          
        scanOnePort(host)
    elif action == 2:
        scanAllPorts(host)
    elif action == 3:
        Checkingsite(host)